package test;

import java.io.IOException;

import webServer.Config;
import junit.framework.TestCase;

/**
 *  <pre>
 *  Copyright (c) 2006 Dominik Schulz
 *  Copyright (c) 2006 Florian Lindner
 *  Copyright (c) 2006 Philip Hartmann
 *  
 *  This file is part of jHTTPd.
 *
 *  jHTTPd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  jHTTPd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with jHTTPd; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  </pre>
 *  
 * @author Dominik
 * 
 */
public class ConfigTest extends TestCase {

	private Config conf = null;

	public void setUp() {
		conf = new Config();
		try {
			conf.readConfig("jhttpd.conf");
		} catch (IOException e) {
			fail("Exception!");
		}
	}

	public void tearDown() {
		conf = null;
	}

	/**
	 * Test method for {@link webServer.Config#setPort(int)}.
	 */
	public void testSetPortInt() {
		int port = 1000;
		conf.setPort(port);
		assertEquals(conf.getPort(), port);
	}

	/**
	 * Test method for {@link webServer.Config#setPort(java.lang.String)}.
	 */
	public void testSetPortString() {
		String port = "1000";
		conf.setPort(port);
		assertEquals(conf.getPort(), Integer.parseInt(port));
	}

	/**
	 * Test method for {@link webServer.Config#getPort()}.
	 */
	public void testGetPort() {
		int port = 1000;
		conf.setPort(port);
		assertEquals(conf.getPort(), port);
	}

	/**
	 * Test method for {@link webServer.Config#getMimeType(java.lang.String)}.
	 */
	public void testGetMimeTypeString() {
		assertEquals(conf.getMimeType("html"), "text/html");
	}

	/**
	 * Test method for {@link webServer.Config#getMimeType()}.
	 */
	public void testGetMimeType() {
		assertEquals(conf.getMimeType(), "text/plain");
	}

	/**
	 * Test method for {@link webServer.Config#readConfig(java.lang.String)}.
	 */
	public void testReadConfig() {
		assertEquals(conf.getMimeType("otp"),
				"application/vnd.oasis.opendocument.presentation-template");
	}

	/**
	 * Test method for {@link webServer.Config#getDefaultCharset()}.
	 */
	public void testGetDefaultCharset() {
		assertEquals(conf.getDefaultCharset(), "ISO-8859-1");
	}

	/**
	 * Test method for {@link webServer.Config#countDown()}.
	 */
	public void testCountDown() {
		conf.countDown();
		assertTrue(true);
	}

	/**
	 * Test method for {@link webServer.Config#countUp()}.
	 */
	public void testCountUp() {
		conf.countUp();
		assertTrue(true);
	}

	/**
	 * Test method for {@link webServer.Config#getRunningThreads()}.
	 */
	public void testGetRunningThreads() {
		int loops = 10000;
		for (int i = 0; i < loops; i++) {
			conf.countUp();
		}
		assertEquals(conf.getRunningThreads(), loops);
		for (int i = 0; i < loops; i++) {
			conf.countDown();
		}
		assertEquals(conf.getRunningThreads(), 0);
	}

}
