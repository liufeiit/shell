/**
 * 
 */
package test;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import junit.framework.TestCase;
import webServer.Config;
import webServer.Header;

/**
 * <pre>
 *   Copyright (c) 2006 Dominik Schulz
 *   Copyright (c) 2006 Florian Lindner
 *   Copyright (c) 2006 Philip Hartmann
 *   
 *   This file is part of jHTTPd.
 * 
 *   jHTTPd is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 * 
 *   jHTTPd is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *   
 *   You should have received a copy of the GNU General Public License
 *   along with jHTTPd; if not, write to the Free Software
 *   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 * </pre>
 * 
 * @author Dominik
 * @author Florian
 * 
 */
public class HeaderTest extends TestCase {

	protected Header hd;

	protected OutputStream os;

	protected String testline;

	public void setUp() {
		os = new ByteArrayOutputStream();
		hd = new Header(os);
		testline = "Test: dgfeg";
	}

	/**
	 * Test method for {@link webServer.Header#addHeaderLine(java.lang.String)}.
	 */
	public void testAddHeaderLine() {
		hd.addHeaderLine("Test: dgfeg");
		assertTrue(true);
	}

	/**
	 * Test method for {@link webServer.Header#sendHeader()}.
	 */
	public void testSendHeader() {
		hd.addHeaderLine(testline);
		try {
			hd.sendHeader();
		} catch (IOException e) {
			fail("Exception");
		}
		String header = os.toString();

		String result = testline + Config.CRLF + "Server: " + Config.SIGNATURE
				+ Config.CRLF + Config.CRLF;

		assertEquals(result, header);
	}

}
