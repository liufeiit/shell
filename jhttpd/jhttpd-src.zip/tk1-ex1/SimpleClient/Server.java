package SimpleClient;

/*
 * Framework aus Beispiel auf der Homepage
 */

import java.io.*;
import java.net.*;

/**
 *  <pre>
 *  Copyright (c) 2006 Dominik Schulz
 *  Copyright (c) 2006 Florian Lindner
 *  Copyright (c) 2006 Philip Hartmann
 *  
 *  This file is part of jHTTPd.
 *
 *  jHTTPd is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  jHTTPd is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *  
 *  You should have received a copy of the GNU General Public License
 *  along with jHTTPd; if not, write to the Free Software
 *  Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
 *  </pre>
 *  
 * @author Dominik
 * @author Philip
 *
 */
public final class Server {

    public static void main(String[] argv) throws Exception {

        try {

            if (argv.length < 2) {
                System.err.println("FEHLER: Zu wenige Argumente");
                System.err.println("Benutzung:");
                System.err.println("Server <port> <message-for-client>");
                throw new RuntimeException("zu wenige Argumente");
            }

            int port = Integer.parseInt(argv[0]);
            String messageToClient = argv[1];

            ServerSocket listenSocket = new ServerSocket(port);

            Socket connectionSocket = listenSocket.accept();

            InputStream is = connectionSocket.getInputStream();
            OutputStream os = connectionSocket.getOutputStream();

            InputStreamReader isr = new InputStreamReader(is);
            BufferedReader br = new BufferedReader(isr);

            OutputStreamWriter osw = new OutputStreamWriter(os);
            BufferedWriter bw = new BufferedWriter(osw);

            String messageFromClient = br.readLine();

            System.out.println(messageFromClient);

            bw.write(messageToClient + "\n");
            bw.flush();

            bw.close();
            br.close();

            connectionSocket.close();
            listenSocket.close();
        }
        catch (Exception e) {
            System.out.println("Fehler aufgetreten: " + e.getMessage());
        }
    }
}
